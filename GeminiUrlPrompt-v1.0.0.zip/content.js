"use strict";
(() => {
  // src/utils/constants.ts
  var INPUT_SELECTORS = [
    // Standard rich-textarea contenteditable
    'rich-textarea .ql-editor[contenteditable="true"]',
    'rich-textarea [contenteditable="true"]',
    "rich-textarea .ql-editor",
    '.ql-editor[contenteditable="true"]',
    '[contenteditable="true"][role="textbox"]',
    'rich-textarea div[role="textbox"]',
    "rich-textarea p",
    'div[contenteditable="true"]',
    'input-area-v2 [contenteditable="true"]',
    'input-area [contenteditable="true"]',
    'chat-window [contenteditable="true"]',
    // XPath fallbacks
    '//rich-textarea//*[@contenteditable="true"]',
    "//rich-textarea//p",
    '//div[@contenteditable="true"]',
    '//div[@role="textbox"]'
  ];
  var SEND_BUTTON_SELECTORS = [
    // 繁體中文（台灣、香港常見標籤）
    'button[aria-label="\u50B3\u9001\u8A0A\u606F"]',
    'button[aria-label*="\u50B3\u9001"]',
    'button[aria-label*="\u9001\u51FA"]',
    'button[aria-label*="\u767C\u9001"]',
    // 簡體中文
    'button[aria-label="\u53D1\u9001\u6D88\u606F"]',
    'button[aria-label*="\u53D1\u9001"]',
    // 英文
    'button[aria-label="Send message"]',
    'button[aria-label*="Send" i]',
    'button[aria-label*="Submit" i]',
    'button[aria-label*="prompt" i]',
    // 日文
    'button[aria-label="\u30D7\u30ED\u30F3\u30D7\u30C8\u3092\u9001\u4FE1"]',
    'button[aria-label*="\u9001\u4FE1"]',
    // Test IDs & 特殊屬性
    'button[data-testid="send-button"]',
    'button[data-test-id="send-button"]',
    // 圖示或特定子元素
    'button:has(mat-icon[fonticon="send"])',
    'button:has(mat-icon[data-mat-icon-name="send"])',
    // Class-based
    "button.send-button",
    'div[class*="send-button-container"] button',
    "div.send-button button",
    ".send-button-container button",
    "send-button button",
    "input-area-v2 button.send-button",
    "input-area button.send-button",
    "gem-icon-button button",
    // XPath fallbacks
    '//button[contains(@aria-label, "\u50B3\u9001") or contains(@aria-label, "Send") or contains(@aria-label, "\u9001\u51FA") or contains(@aria-label, "\u767C\u9001") or contains(@aria-label, "\u53D1\u9001") or contains(@aria-label, "\u9001\u4FE1")]',
    '//div[contains(@class, "send-button")]//button',
    '//button[contains(@class, "send-button")]',
    "//gem-icon-button//button"
  ];
  var DEFAULT_TIMEOUT = 25e3;

  // src/utils/url.ts
  function extractPromptFromUrl(urlString) {
    if (!urlString) return null;
    try {
      const url = new URL(urlString);
      let p = url.searchParams.get("p");
      if (p && p.trim()) return p.trim();
      if (url.hash && url.hash.includes("?")) {
        const hashQuery = url.hash.split("?")[1];
        const hashParams = new URLSearchParams(hashQuery);
        p = hashParams.get("p");
        if (p && p.trim()) return p.trim();
      }
      return null;
    } catch {
      const match = urlString.match(/[?&]p=([^&#]+)/);
      if (match && match[1]) {
        try {
          return decodeURIComponent(match[1].replace(/\+/g, " ")).trim();
        } catch {
          return match[1].trim();
        }
      }
      return null;
    }
  }
  function removePromptFromUrl(urlString) {
    if (!urlString) return urlString;
    try {
      const url = new URL(urlString);
      if (!url.searchParams.has("p")) {
        return urlString;
      }
      url.searchParams.delete("p");
      return url.toString();
    } catch {
      return urlString.replace(/([?&])p=[^&#]*(&|$)/, (m, p1, p2) => p2 ? p1 : "").replace(/[?&]$/, "");
    }
  }

  // src/utils/dom.ts
  function querySelectorOrXPath(selector, root = document) {
    if (!selector) return null;
    if (selector.startsWith("//") || selector.startsWith("/html")) {
      try {
        const doc = root.ownerDocument || root;
        const result = doc.evaluate(selector, root, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
        return result.singleNodeValue;
      } catch {
        return null;
      }
    } else {
      try {
        return root.querySelector(selector);
      } catch {
        return null;
      }
    }
  }
  function findElementByCandidates(candidates, root = document) {
    for (const selector of candidates) {
      const el = querySelectorOrXPath(selector, root);
      if (el) return el;
    }
    return null;
  }
  function waitForElement(candidates, timeout = 25e3, interval = 300, root = document) {
    return new Promise((resolve, reject) => {
      const startTime = Date.now();
      const initial = findElementByCandidates(candidates, root);
      if (initial) {
        resolve(initial);
        return;
      }
      const timer = setInterval(() => {
        const el = findElementByCandidates(candidates, root);
        if (el) {
          clearInterval(timer);
          resolve(el);
          return;
        }
        if (Date.now() - startTime >= timeout) {
          clearInterval(timer);
          reject(new Error(`Timeout waiting for element matching: ${candidates.join(", ")}`));
        }
      }, interval);
    });
  }
  async function waitForEnabledSendButton(candidates, timeout = 6e3, interval = 150) {
    const startTime = Date.now();
    let foundDisabledButton = null;
    while (Date.now() - startTime < timeout) {
      for (const selector of candidates) {
        const el = querySelectorOrXPath(selector);
        if (el) {
          const isDisabled = el.disabled || el.getAttribute("aria-disabled") === "true";
          if (!isDisabled) {
            return el;
          }
          foundDisabledButton = el;
        }
      }
      await new Promise((r) => setTimeout(r, interval));
    }
    return foundDisabledButton;
  }
  async function injectPrompt(inputElement, prompt) {
    try {
      const editor = inputElement.closest('[contenteditable="true"]') || inputElement;
      editor.focus();
      let inserted = false;
      try {
        const selection = window.getSelection();
        if (selection) {
          const range = document.createRange();
          range.selectNodeContents(editor);
          selection.removeAllRanges();
          selection.addRange(range);
        }
        inserted = document.execCommand("insertText", false, prompt);
      } catch {
        inserted = false;
      }
      if (!inserted || !editor.textContent || editor.textContent.trim().length === 0) {
        console.log("[GeminiUrlPrompt] execCommand \u672A\u80FD\u6210\u529F\u5BEB\u5165\uFF0C\u4F7F\u7528 DOM \u7D50\u69CB\u6CE8\u5165");
        editor.innerHTML = "";
        const lines = prompt.split("\n");
        for (const line of lines) {
          const p = document.createElement("p");
          p.textContent = line || "\u200B";
          editor.appendChild(p);
        }
      }
      try {
        const selection = window.getSelection();
        if (selection) {
          const range = document.createRange();
          range.selectNodeContents(editor);
          range.collapse(false);
          selection.removeAllRanges();
          selection.addRange(range);
        }
      } catch {
      }
      editor.dispatchEvent(
        new InputEvent("input", {
          bubbles: true,
          cancelable: true,
          inputType: "insertText",
          data: prompt
        })
      );
      editor.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
      editor.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
      const parentRich = editor.closest("rich-textarea");
      if (parentRich) {
        parentRich.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
        parentRich.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
      }
      return true;
    } catch (e) {
      console.error("[GeminiUrlPrompt] \u5BEB\u5165\u63D0\u793A\u8A5E\u5931\u6557:", e);
      return false;
    }
  }
  function triggerClick(element) {
    element.focus();
    element.dispatchEvent(new PointerEvent("pointerdown", { bubbles: true, cancelable: true }));
    element.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true }));
    element.dispatchEvent(new PointerEvent("pointerup", { bubbles: true, cancelable: true }));
    element.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true }));
    element.click();
  }
  function triggerEnter(element) {
    element.focus();
    const eventOptions = {
      key: "Enter",
      code: "Enter",
      keyCode: 13,
      which: 13,
      bubbles: true,
      cancelable: true,
      composed: true,
      shiftKey: false,
      ctrlKey: false,
      altKey: false,
      metaKey: false
    };
    element.dispatchEvent(new KeyboardEvent("keydown", eventOptions));
    element.dispatchEvent(new KeyboardEvent("keypress", eventOptions));
    element.dispatchEvent(new KeyboardEvent("keyup", eventOptions));
  }
  async function submitPrompt(sendButton, inputElement) {
    const editor = inputElement.closest('[contenteditable="true"]') || inputElement;
    if (sendButton) {
      console.log("[GeminiUrlPrompt] \u627E\u5230\u9001\u51FA\u6309\u9215\uFF0C\u6E96\u5099\u89F8\u767C\u9EDE\u64CA:", sendButton);
      await new Promise((r) => setTimeout(r, 200));
      triggerClick(sendButton);
      await new Promise((r) => setTimeout(r, 500));
      const stillHasText = (editor.textContent || "").trim().length > 0;
      if (!stillHasText) {
        console.log("[GeminiUrlPrompt] \u5075\u6E2C\u5230\u8F38\u5165\u6846\u5DF2\u6E05\u7A7A\uFF0C\u9001\u51FA\u6210\u529F\uFF01");
        return true;
      }
      console.log("[GeminiUrlPrompt] \u9EDE\u64CA\u5F8C\u8F38\u5165\u6846\u5C1A\u672A\u6E05\u7A7A\uFF0C\u57F7\u884C Enter \u9375\u5099\u63F4\u9001\u51FA...");
    } else {
      console.log("[GeminiUrlPrompt] \u672A\u627E\u5230\u9001\u51FA\u6309\u9215\uFF0C\u76F4\u63A5\u57F7\u884C Enter \u9375\u5099\u63F4\u9001\u51FA...");
    }
    triggerEnter(editor);
    await new Promise((r) => setTimeout(r, 300));
    return true;
  }

  // src/content.ts
  var lastProcessedPrompt = null;
  var isProcessing = false;
  async function checkAndExecute() {
    if (isProcessing) return;
    const prompt = extractPromptFromUrl(window.location.href);
    if (!prompt || prompt === lastProcessedPrompt) {
      return;
    }
    isProcessing = true;
    console.log("[GeminiUrlPrompt] \u5075\u6E2C\u5230\u63D0\u793A\u8A5E\u53C3\u6578:", prompt);
    try {
      const inputElement = await waitForElement(INPUT_SELECTORS, DEFAULT_TIMEOUT);
      console.log("[GeminiUrlPrompt] \u6210\u529F\u5B9A\u4F4D\u8F38\u5165\u6846:", inputElement);
      const injected = await injectPrompt(inputElement, prompt);
      if (!injected) {
        console.error("[GeminiUrlPrompt] \u6CE8\u5165\u63D0\u793A\u8A5E\u5931\u6557\uFF0C\u653E\u68C4\u9001\u51FA");
        return;
      }
      console.log("[GeminiUrlPrompt] \u7B49\u5F85\u9001\u51FA\u6309\u9215\u555F\u7528...");
      const sendButton = await waitForEnabledSendButton(SEND_BUTTON_SELECTORS, 6e3, 150);
      const submitted = await submitPrompt(sendButton, inputElement);
      if (submitted) {
        console.log("[GeminiUrlPrompt] \u63D0\u793A\u8A5E\u9001\u51FA\u5B8C\u6210\uFF01");
        lastProcessedPrompt = prompt;
      }
      const cleanUrl = removePromptFromUrl(window.location.href);
      if (cleanUrl !== window.location.href) {
        window.history.replaceState({}, document.title, cleanUrl);
      }
    } catch (err) {
      console.error("[GeminiUrlPrompt] \u57F7\u884C\u81EA\u52D5\u586B\u5165\u5931\u6557:", err);
    } finally {
      isProcessing = false;
    }
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => checkAndExecute());
  } else {
    checkAndExecute();
  }
  window.addEventListener("popstate", () => checkAndExecute());
  var currentUrl = window.location.href;
  setInterval(() => {
    if (window.location.href !== currentUrl) {
      currentUrl = window.location.href;
      checkAndExecute();
    }
  }, 800);
})();
